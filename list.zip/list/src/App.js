import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [tasks, setTasks] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [editIndex, setEditIndex] = useState(null);
  const [searchValue, setSearchValue] = useState('');
  const [expandedTaskIndex, setExpandedTaskIndex] = useState(null);

  useEffect(() => {
    fetch('http://localhost:5000/tasks')
      .then(response => response.json())
      .then(data => setTasks(data))
      .catch(error => console.error('Error fetching tasks:', error));
  }, []);

  const saveTasks = (newTasks) => {
    setTasks(newTasks);
    newTasks.forEach(task => {
      fetch(`http://localhost:5000/tasks/${task.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(task)
      })
      .catch(error => console.error('Error saving tasks:', error));
    });
  };

  const addOrUpdateTask = () => {
    if (inputValue.trim() === '') {
      alert('Note is empty');
      return;
    }

    if (editIndex !== null) {
      const updatedTasks = tasks.map((task, index) => {
        if (index === editIndex) {
          return { ...task, text: inputValue };
        }
        return task;
      });
      saveTasks(updatedTasks);
      setEditIndex(null);
    } else {
      const newTask = {
        id: tasks.length ? tasks[tasks.length - 1].id + 1 : 1,
        text: inputValue,
        description: 'Default description',
        timestamp: new Date().toLocaleString(),
        completed: false
      };
      const newTasks = [...tasks, newTask];
      fetch('http://localhost:5000/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTask)
      })
      .then(response => response.json())
      .then(data => setTasks(newTasks))
      .catch(error => console.error('Error adding task:', error));
    }

    setInputValue('');
  };

  const toggleTask = (index) => {
    const newTasks = tasks.map((task, i) => {
      if (i === index) {
        return { ...task, completed: !task.completed };
      }
      return task;
    });
    saveTasks(newTasks);
  };

  const deleteTask = (index) => {
    const taskToDelete = tasks[index];
    const newTasks = tasks.filter((_, i) => i !== index);
    fetch(`http://localhost:5000/tasks/${taskToDelete.id}`, {
      method: 'DELETE'
    })
    .then(() => setTasks(newTasks))
    .catch(error => console.error('Error deleting task:', error));
  };

  const toggleExpand = (index) => {
    if (expandedTaskIndex === index) {
      setExpandedTaskIndex(null);
    } else {
      setExpandedTaskIndex(index);
    }
  };

  const editTask = (index) => {
    setInputValue(tasks[index].text);
    setEditIndex(index);
  };

  const filteredTasks = tasks.filter(task => 
    task.text.toLowerCase().includes(searchValue.toLowerCase())
  );

  return (
    <div className="container">
      <div className="box">
        <h1>To-Do list</h1>
        <div className="add">
          <input
            type="text"
            id="input-box"
            placeholder="Add Your Text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
          />
          <button className="btn" onClick={addOrUpdateTask}>
            {editIndex !== null ? 'Update' : 'Add'}
          </button>
        </div>
        <div className="search">
          <input
            type="text"
            id="search-box"
            placeholder="Search Tasks"
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
          />
        </div>
        <ul className="note" id="list-container">
          {filteredTasks.map((task, index) => (
            <li key={index} className={task.completed ? 'checked' : ''}>
              <span onClick={() => toggleTask(index)}>{task.text}</span>
              <span className="edit-btn" onClick={() => editTask(index)}>✎</span>
              <span className="delete-btn" onClick={() => deleteTask(index)}>&#x00D7;</span>
              <button onClick={() => toggleExpand(index)}>
                {expandedTaskIndex === index ? 'Collapse' : 'Expand'}
              </button>
              {expandedTaskIndex === index && (
                <div className="task-details">
                  <p><strong>Description:</strong> {task.description}</p>
                  <p><strong>Timestamp:</strong> {task.timestamp}</p>
                </div>
              )}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;
